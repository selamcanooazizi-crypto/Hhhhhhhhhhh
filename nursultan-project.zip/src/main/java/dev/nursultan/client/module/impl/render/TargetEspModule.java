package dev.nursultan.client.module.impl.render;

import dev.nursultan.client.module.Category;
import dev.nursultan.client.module.Module;
import dev.nursultan.client.module.ModuleManager;
import dev.nursultan.client.module.setting.BooleanSetting;
import dev.nursultan.client.module.setting.ModeSetting;
import dev.nursultan.client.module.setting.NumberSetting;
import dev.nursultan.client.util.ClientTheme;
import dev.nursultan.client.util.TargetUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class TargetEspModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final ModeSetting mode = new ModeSetting("Mode", "Ring", "Ring", "Circle", "Box");
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.2, 3.0, 0.1);
    private final BooleanSetting hurt = new BooleanSetting("Hurt Color", true);

    public TargetEspModule() {
        super("Target ESP", Category.RENDER);
        addSettings(mode, speed, hurt);
    }

    /** NursultanClient.onInitializeClient icinde bir kez cagir. */
    public static void registerWorldRender() {
        WorldRenderEvents.LAST.register(TargetEspModule::onWorld);
    }

    private static void onWorld(WorldRenderContext ctx) {
        Module m = ModuleManager.INSTANCE.get(TargetEspModule.class);
        if (!(m instanceof TargetEspModule esp) || !esp.isEnabled()) return;
        LivingEntity t = TargetUtil.getCurrent();
        if (t != null) esp.draw(ctx, t);
    }

    private void draw(WorldRenderContext ctx, LivingEntity t) {
        VertexConsumerProvider consumers = ctx.consumers();
        MatrixStack ms = ctx.matrixStack();
        if (consumers == null || ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        double x = MathHelper.lerp(td, t.prevX, t.getX()) - cam.x;
        double y = MathHelper.lerp(td, t.prevY, t.getY()) - cam.y;
        double z = MathHelper.lerp(td, t.prevZ, t.getZ()) - cam.z;

        int c = (hurt.get() && t.hurtTime > 0) ? 0xFFFF3030 : ClientTheme.color(0);
        float r = ((c >> 16) & 0xFF) / 255f, g = ((c >> 8) & 0xFF) / 255f, b = (c & 0xFF) / 255f;

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        MatrixStack.Entry e = ms.peek();
        double radius = t.getWidth() * 0.8 + 0.1;
        double cycle = 2000.0 / speed.get();
        double phase = (System.currentTimeMillis() % (long) cycle) / cycle;

        switch (mode.getMode()) {
            case "Box" -> {
                Box box = t.getBoundingBox().offset(
                        x - t.getX() + 0.0, y - t.getY() + 0.0, z - t.getZ() + 0.0);
                WorldRenderer.drawBox(ms, vc, box, r, g, b, 1f);
            }
            case "Circle" -> {
                double pulse = radius * (1.0 + 0.08 * Math.sin(phase * Math.PI * 2));
                ring(vc, e, x, y + 0.02, z, pulse, r, g, b, 1f);
            }
            default -> { // Ring: yukari asagi gezen halka + iz
                double wave = 0.5 + 0.5 * Math.sin(phase * Math.PI * 2);
                double h = t.getHeight() * wave;
                ring(vc, e, x, y + h, z, radius, r, g, b, 1f);
                ring(vc, e, x, y + h - 0.08, z, radius, r, g, b, 0.55f);
                ring(vc, e, x, y + h - 0.16, z, radius, r, g, b, 0.25f);
            }
        }

        if (consumers instanceof VertexConsumerProvider.Immediate imm) {
            imm.draw(RenderLayer.getLines());
        }
    }

    private static void ring(VertexConsumer vc, MatrixStack.Entry e,
                             double cx, double cy, double cz, double radius,
                             float r, float g, float b, float a) {
        final int segments = 48;
        for (int i = 0; i < segments; i++) {
            double a1 = Math.PI * 2 * i / segments;
            double a2 = Math.PI * 2 * (i + 1) / segments;
            line(vc, e,
                    cx + Math.cos(a1) * radius, cy, cz + Math.sin(a1) * radius,
                    cx + Math.cos(a2) * radius, cy, cz + Math.sin(a2) * radius,
                    r, g, b, a);
        }
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry e,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             float r, float g, float b, float a) {
        float dx = (float) (x2 - x1), dy = (float) (y2 - y1), dz = (float) (z2 - z1);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-6f) return;
        dx /= len; dy /= len; dz /= len;
        vc.vertex(e, (float) x1, (float) y1, (float) z1).color(r, g, b, a).normal(e, dx, dy, dz);
        vc.vertex(e, (float) x2, (float) y2, (float) z2).color(r, g, b, a).normal(e, dx, dy, dz);
    }
}
