package dev.nursultan.client.module.impl.combat;

import dev.nursultan.client.module.Category;
import dev.nursultan.client.module.Module;
import dev.nursultan.client.module.setting.BooleanSetting;
import dev.nursultan.client.module.setting.ModeSetting;
import dev.nursultan.client.module.setting.NumberSetting;
import dev.nursultan.client.util.RotationUtil;
import dev.nursultan.client.util.TargetUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public class AttackAuraModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final NumberSetting range = new NumberSetting("Range", 3.0, 2.5, 6.0, 0.1);
    private final NumberSetting rotRange = new NumberSetting("Rotation Range", 3.6, 2.5, 8.0, 0.1);
    private final NumberSetting rotSpeed = new NumberSetting("Rotation Speed", 45, 10, 180, 5);
    private final NumberSetting jitter = new NumberSetting("Jitter", 0.4, 0.0, 2.0, 0.1);
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 0.92, 0.5, 1.0, 0.01);
    private final ModeSetting priority = new ModeSetting("Priority", "Distance", "Distance", "Health", "Angle");
    private final ModeSetting aimPoint = new ModeSetting("Aim Point", "Nearest", "Nearest", "Head", "Chest");
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", false);
    private final BooleanSetting animals = new BooleanSetting("Animals", false);
    private final BooleanSetting invisible = new BooleanSetting("Invisible", false);
    private final BooleanSetting throughWalls = new BooleanSetting("Through Walls", false);
    private final BooleanSetting raycast = new BooleanSetting("Raycast", true);
    private final BooleanSetting onlyCrits = new BooleanSetting("Only Crits", false);
    private final BooleanSetting mouseStep = new BooleanSetting("Mouse Step", true);

    private boolean hasTarget;

    public AttackAuraModule() {
        super("AttackAura", Category.COMBAT);
        addSettings(range, rotRange, rotSpeed, jitter, cooldown, priority, aimPoint,
                players, mobs, animals, invisible, throughWalls, raycast, onlyCrits, mouseStep);
    }

    public boolean hasTarget() {
        return hasTarget;
    }

    @Override
    public void onDisable() {
        hasTarget = false;
        TargetUtil.setAura(null);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            hasTarget = false;
            return;
        }

        LivingEntity t = TargetUtil.find(rotRange.get(), players.get(), mobs.get(), animals.get(),
                invisible.get(), throughWalls.get(), priority.getMode());
        TargetUtil.setAura(t);
        hasTarget = t != null;
        if (t == null) return;

        // ---- Rotasyon (yumusak) ----
        Vec3d eye = p.getEyePos();
        Vec3d aim = RotationUtil.aimPoint(t, aimPoint.getMode(), eye);
        float[] want = RotationUtil.rotationsTo(eye, aim);

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        float j = (float) jitter.get();
        if (j > 0f) {
            want[0] += (rnd.nextFloat() - 0.5f) * 2f * j;
            want[1] += (rnd.nextFloat() - 0.5f) * 2f * j;
        }

        float speed = (float) rotSpeed.get() * (0.85f + rnd.nextFloat() * 0.3f);
        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(want[0] - p.getYaw()), -speed, speed);
        float dPitch = MathHelper.clamp(want[1] - p.getPitch(), -speed * 0.6f, speed * 0.6f);
        if (mouseStep.get()) {
            dYaw = RotationUtil.snap(dYaw);
            dPitch = RotationUtil.snap(dPitch);
        }

        float newYaw = p.getYaw() + dYaw;
        float newPitch = MathHelper.clamp(p.getPitch() + dPitch, -90f, 90f);
        p.setYaw(newYaw);
        p.setPitch(newPitch);

        // ---- Saldiri kontrolleri ----
        double dist = TargetUtil.distanceToBox(eye, t.getBoundingBox());
        if (dist > range.get()) return;
        if (p.getAttackCooldownProgress(0.5f) < cooldown.get()) return;
        if (onlyCrits.get() && !canCrit(p)) return;
        if (raycast.get() && !RotationUtil.hitsTarget(p, t, newYaw, newPitch, range.get() + 0.05)) return;

        // Sunucu once yeni bakis acisini gorsun, sonra vurus gelsin.
        if (p.networkHandler != null) {
            p.networkHandler.sendPacket(
                    new PlayerMoveC2SPacket.LookAndOnGround(newYaw, newPitch, p.isOnGround()));
        }
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    private boolean canCrit(ClientPlayerEntity p) {
        if (p.isFallFlying()) return true;
        return p.fallDistance > 0.0f && !p.isOnGround() && !p.isClimbing()
                && !p.isTouchingWater() && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle();
    }
}
