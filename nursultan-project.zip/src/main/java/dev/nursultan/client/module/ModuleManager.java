package dev.nursultan.client.module;

import dev.nursultan.client.module.impl.combat.AttackAuraModule;
import dev.nursultan.client.module.impl.combat.ElytraTargetModule;
import dev.nursultan.client.module.impl.render.TargetEspModule;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final ModuleManager INSTANCE = new ModuleManager();

    private final List<Module> modules = new ArrayList<>();

    private ModuleManager() {
        register(new AttackAuraModule(), false);
        register(new ElytraTargetModule(), false);
        register(new TargetEspModule(), false);
    }

    public void register(Module module, boolean enabledByDefault) {
        modules.add(module);
        if (enabledByDefault) module.setEnabled(true);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> byCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) out.add(m);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (m.getClass() == type) return (T) m;
        }
        return null;
    }
}
