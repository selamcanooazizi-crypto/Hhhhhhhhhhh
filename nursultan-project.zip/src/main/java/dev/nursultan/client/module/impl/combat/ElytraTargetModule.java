package dev.nursultan.client.module.impl.combat;

import dev.nursultan.client.module.Category;
import dev.nursultan.client.module.Module;
import dev.nursultan.client.module.ModuleManager;
import dev.nursultan.client.module.setting.BooleanSetting;
import dev.nursultan.client.module.setting.ModeSetting;
import dev.nursultan.client.module.setting.NumberSetting;
import dev.nursultan.client.util.RotationUtil;
import dev.nursultan.client.util.TargetUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ElytraTargetModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final NumberSetting distance = new NumberSetting("Distance", 48, 8, 96, 2);
    private final NumberSetting speed = new NumberSetting("Rotation Speed", 25, 5, 90, 1);
    private final NumberSetting predict = new NumberSetting("Prediction", 0.5, 0.0, 1.0, 0.1);
    private final ModeSetting firework = new ModeSetting("Firework", "Auto", "Auto", "Off");
    private final NumberSetting minSpeed = new NumberSetting("Min Speed", 1.0, 0.3, 2.5, 0.1);
    private final NumberSetting fwDelay = new NumberSetting("Firework Delay", 20, 5, 60, 1);
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", false);

    private int fwCooldown;

    public ElytraTargetModule() {
        super("Elytra Target", Category.COMBAT);
        addSettings(distance, speed, predict, firework, minSpeed, fwDelay, players, mobs);
    }

    @Override
    public void onDisable() {
        TargetUtil.setElytra(null);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || !p.isFallFlying()) {
            TargetUtil.setElytra(null);
            return;
        }
        if (fwCooldown > 0) fwCooldown--;

        LivingEntity t = TargetUtil.find(distance.get(), players.get(), mobs.get(), false, false, true, "Distance");
        TargetUtil.setElytra(t);
        if (t == null) return;

        // Yakin mesafede AttackAura hedefe bakiyorsa rotasyonu o yonetsin.
        Module m = ModuleManager.INSTANCE.get(AttackAuraModule.class);
        boolean auraBusy = m instanceof AttackAuraModule a && a.isEnabled() && a.hasTarget();

        if (!auraBusy) {
            Vec3d eye = p.getEyePos();
            double dist = eye.distanceTo(t.getPos());

            // Hedefin hareket yonune dogru on tahmin (carpisma noktasi)
            Vec3d vel = new Vec3d(t.getX() - t.prevX, t.getY() - t.prevY, t.getZ() - t.prevZ);
            double ticks = Math.min(dist / Math.max(p.getVelocity().length(), 0.6), 20.0) * predict.get();
            Vec3d aim = new Vec3d(t.getX(), t.getY() + t.getHeight() * 0.5, t.getZ()).add(vel.multiply(ticks));

            float[] want = RotationUtil.rotationsTo(eye, aim);
            float s = (float) speed.get();
            float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(want[0] - p.getYaw()), -s, s);
            float dPitch = MathHelper.clamp(want[1] - p.getPitch(), -s, s);
            p.setYaw(p.getYaw() + dYaw);
            p.setPitch(MathHelper.clamp(p.getPitch() + dPitch, -90f, 90f));
        }

        // ---- Otomatik havai fisek ----
        if (firework.getMode().equals("Auto") && fwCooldown <= 0
                && p.getVelocity().length() < minSpeed.get()) {
            if (useFirework(p)) fwCooldown = (int) fwDelay.get();
        }
    }

    private boolean useFirework(ClientPlayerEntity p) {
        if (mc.interactionManager == null) return false;

        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            p.swingHand(Hand.OFF_HAND);
            return true;
        }
        if (p.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            return true;
        }

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                slot = i;
                break;
            }
        }
        if (slot == -1) return false;

        int prev = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND); // slot paketi otomatik gonderilir
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().selectedSlot = prev;                   // sonraki tick'te eski slota doner
        return true;
    }
}
