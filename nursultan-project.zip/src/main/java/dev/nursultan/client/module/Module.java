package dev.nursultan.client.module;

import dev.nursultan.client.module.setting.Setting;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    private boolean expanded;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected void addSettings(Setting... s) {
        for (Setting setting : s) settings.add(setting);
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public List<Setting> getSettings() {
        return settings;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        if (this.enabled == value) return;
        this.enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void toggleExpanded() {
        expanded = !expanded;
    }

    public void onEnable() {}

    public void onDisable() {}

    public void onTick() {}

    public void onRender2D(DrawContext context, float tickDelta) {}
}
