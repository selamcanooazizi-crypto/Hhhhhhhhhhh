package dev.nursultan.client.module.setting;

public class ModeSetting extends Setting {
    private final String[] modes;
    private int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(def)) index = i;
        }
    }

    public String getMode() {
        return modes[index];
    }

    public void cycle() {
        index = (index + 1) % modes.length;
    }
}
