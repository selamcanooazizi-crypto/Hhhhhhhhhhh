package dev.nursultan.client.module;

public enum Category {
    COMBAT("Combat"),
    RENDER("Render"),
    VISUALS("Visuals"),
    HUD("HUD"),
    WORLD("World"),
    MISC("Misc");

    private final String title;

    Category(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
