package dev.nursultan.client.module.setting;

import java.util.Locale;

public class NumberSetting extends Setting {
    private double value;
    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(value);
    }

    public double get() {
        return value;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public void set(double v) {
        double snapped = step > 0 ? Math.round(v / step) * step : v;
        snapped = Math.round(snapped * 1000.0) / 1000.0;
        this.value = Math.max(min, Math.min(max, snapped));
    }

    public String display() {
        if (step >= 1.0) return String.valueOf((int) Math.round(value));
        return String.format(Locale.US, "%.2f", value);
    }
}
