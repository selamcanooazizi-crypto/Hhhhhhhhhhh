package dev.nursultan.client.util;

public final class ClientTheme {
    private static final int PURPLE = 0xFFA855F7;
    private static final int BLUE = 0xFF3B82F6;

    private ClientTheme() {}

    /** Mor-mavi arasinda gezinen tema rengi (ARGB). index renk kaymasi icindir. */
    public static int color(int index) {
        double t = System.currentTimeMillis() / 1000.0 + index * 0.15;
        float f = (float) (0.5 + 0.5 * Math.sin(t * 2.0));
        return lerp(PURPLE, BLUE, f);
    }

    public static int lerp(int a, int b, float f) {
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * f);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
