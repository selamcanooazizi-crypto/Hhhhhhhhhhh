package dev.nursultan.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class RotationUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private RotationUtil() {}

    public static float yawTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, h)), -90f, 90f);
    }

    public static float[] rotationsTo(Vec3d from, Vec3d to) {
        return new float[]{yawTo(from, to), pitchTo(from, to)};
    }

    /** Hedefin hitbox'i icinde nereye bakilacagini secer. */
    public static Vec3d aimPoint(LivingEntity t, String mode, Vec3d eye) {
        Box b = t.getBoundingBox();
        return switch (mode) {
            case "Head" -> new Vec3d(t.getX(), t.getEyeY() - 0.1, t.getZ());
            case "Chest" -> new Vec3d(t.getX(), t.getY() + t.getHeight() * 0.65, t.getZ());
            default -> new Vec3d(
                    MathHelper.clamp(eye.x, b.minX + 0.05, b.maxX - 0.05),
                    MathHelper.clamp(eye.y, b.minY + 0.1, b.maxY - 0.1),
                    MathHelper.clamp(eye.z, b.minZ + 0.05, b.maxZ - 0.05));
        };
    }

    /** Fare hassasiyetine gore en kucuk donus adimi (dogal mouse hissi). */
    public static float snap(float delta) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        float step = (float) (f * f * f * 8.0 * 0.15);
        return Math.round(delta / step) * step;
    }

    public static Vec3d lookVec(float yaw, float pitch) {
        float f = pitch * 0.017453292F;
        float g = -yaw * 0.017453292F;
        float h = MathHelper.cos(g), i = MathHelper.sin(g);
        float j = MathHelper.cos(f), k = MathHelper.sin(f);
        return new Vec3d(i * j, -k, h * j);
    }

    /** Verilen yaw/pitch ile bakildiginda hedefin hitbox'ina isin dusuyor mu? */
    public static boolean hitsTarget(ClientPlayerEntity p, LivingEntity t, float yaw, float pitch, double reach) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(lookVec(yaw, pitch).multiply(reach));
        Box box = t.getBoundingBox().expand(t.getTargetingMargin());
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    /** Arada blok var mi? */
    public static boolean canSee(ClientPlayerEntity p, LivingEntity t) {
        if (mc.world == null) return false;
        HitResult r = mc.world.raycast(new RaycastContext(
                p.getEyePos(), t.getEyePos(),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        return r.getType() == HitResult.Type.MISS;
    }
}
