package dev.nursultan.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class TargetUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static LivingEntity auraTarget;
    private static LivingEntity elytraTarget;

    private TargetUtil() {}

    public static void setAura(LivingEntity e) { auraTarget = e; }
    public static void setElytra(LivingEntity e) { elytraTarget = e; }
    public static void clear() { auraTarget = null; elytraTarget = null; }

    private static boolean valid(LivingEntity e) {
        return e != null && e.isAlive() && !e.isRemoved();
    }

    /** ESP / HUD icin su an gosterilecek hedef. */
    public static LivingEntity getCurrent() {
        if (valid(auraTarget)) return auraTarget;
        if (valid(elytraTarget)) return elytraTarget;
        return null;
    }

    public static double distanceToBox(Vec3d eye, Box box) {
        double x = MathHelper.clamp(eye.x, box.minX, box.maxX);
        double y = MathHelper.clamp(eye.y, box.minY, box.maxY);
        double z = MathHelper.clamp(eye.z, box.minZ, box.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    public static LivingEntity find(double range, boolean players, boolean mobs, boolean animals,
                                    boolean invisible, boolean throughWalls, String priority) {
        ClientPlayerEntity self = mc.player;
        if (self == null || mc.world == null) return null;

        Vec3d eye = self.getEyePos();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living) || e == self) continue;
            if (e instanceof ArmorStandEntity) continue;
            if (!living.isAlive() || living.isSpectator()) continue;
            if (!invisible && living.isInvisible()) continue;

            boolean ok = (living instanceof PlayerEntity && players)
                    || (living instanceof Monster && mobs)
                    || (living instanceof AnimalEntity && animals);
            if (!ok) continue;

            double dist = distanceToBox(eye, living.getBoundingBox());
            if (dist > range) continue;
            if (!throughWalls && !RotationUtil.canSee(self, living)) continue;

            double score = switch (priority) {
                case "Health" -> living.getHealth() + living.getAbsorptionAmount();
                case "Angle" -> Math.abs(MathHelper.wrapDegrees(
                        RotationUtil.yawTo(eye, living.getEyePos()) - self.getYaw()));
                default -> dist;
            };
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }
}
