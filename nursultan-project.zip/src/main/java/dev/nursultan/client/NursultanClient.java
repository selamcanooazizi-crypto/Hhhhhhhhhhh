package dev.nursultan.client;

import dev.nursultan.client.gui.ClickGuiScreen;
import dev.nursultan.client.module.Module;
import dev.nursultan.client.module.ModuleManager;
import dev.nursultan.client.module.impl.render.TargetEspModule;
import dev.nursultan.client.util.ClientTheme;
import dev.nursultan.client.util.TargetUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class NursultanClient implements ClientModInitializer {
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nursultan.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.nursultan"));

        // GUI acma tusu
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                client.setScreen(ClickGuiScreen.getInstance());
            }
        });

        // Modul tick: rotasyon hareket paketlerinden ONCE uygulansin diye START
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                TargetUtil.clear();
                return;
            }
            if (client.currentScreen != null) return;
            for (Module m : ModuleManager.INSTANCE.getModules()) {
                if (m.isEnabled()) m.onTick();
            }
        });

        // HUD
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            ctx.drawTextWithShadow(mc.textRenderer, "Nursultan Client", 4, 4, ClientTheme.color(0));
            float td = tickCounter.getTickDelta(false);
            for (Module m : ModuleManager.INSTANCE.getModules()) {
                if (m.isEnabled()) m.onRender2D(ctx, td);
            }
        });

        TargetEspModule.registerWorldRender();
    }
}
