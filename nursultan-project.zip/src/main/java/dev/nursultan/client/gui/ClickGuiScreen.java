package dev.nursultan.client.gui;

import dev.nursultan.client.module.Category;
import dev.nursultan.client.module.Module;
import dev.nursultan.client.module.ModuleManager;
import dev.nursultan.client.module.setting.BooleanSetting;
import dev.nursultan.client.module.setting.ModeSetting;
import dev.nursultan.client.module.setting.NumberSetting;
import dev.nursultan.client.module.setting.Setting;
import dev.nursultan.client.util.ClientTheme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static ClickGuiScreen instance;

    private static final int PW = 110;
    private static final int HH = 16;
    private static final int RH = 14;
    private static final int GAP = 8;
    private static final int TOP = 20;
    private static final int LEFT = 20;

    private record Row(int panel, Module module, Setting setting, int x, int y, int w, int h) {}

    private NumberSetting dragging;
    private int dragX;
    private int dragW;

    private ClickGuiScreen() {
        super(Text.literal("Nursultan"));
    }

    public static ClickGuiScreen getInstance() {
        if (instance == null) instance = new ClickGuiScreen();
        return instance;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Paneller Category.values() sirasiyla soldan saga dizilir. */
    private List<Row> buildRows() {
        List<Row> rows = new ArrayList<>();
        int panel = 0;
        for (Category cat : Category.values()) {
            List<Module> mods = ModuleManager.INSTANCE.byCategory(cat);
            if (mods.isEmpty()) continue;
            int x = LEFT + panel * (PW + GAP);
            int y = TOP;
            rows.add(new Row(panel, null, null, x, y, PW, HH));
            y += HH;
            for (Module m : mods) {
                rows.add(new Row(panel, m, null, x, y, PW, RH));
                y += RH;
                if (m.isExpanded()) {
                    for (Setting s : m.getSettings()) {
                        rows.add(new Row(panel, m, s, x, y, PW, RH));
                        y += RH;
                    }
                }
            }
            panel++;
        }
        return rows;
    }

    private Category categoryOfPanel(int panel) {
        int p = 0;
        for (Category cat : Category.values()) {
            if (ModuleManager.INSTANCE.byCategory(cat).isEmpty()) continue;
            if (p == panel) return cat;
            p++;
        }
        return Category.COMBAT;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);

        for (Row r : buildRows()) {
            int x2 = r.x() + r.w();
            int y2 = r.y() + r.h();

            if (r.module() == null) {
                ctx.fill(r.x(), r.y(), x2, y2, ClientTheme.color(r.panel() * 4));
                ctx.drawTextWithShadow(textRenderer, categoryOfPanel(r.panel()).getTitle(),
                        r.x() + 5, r.y() + 4, 0xFFFFFFFF);
            } else if (r.setting() == null) {
                boolean on = r.module().isEnabled();
                int bg = on ? ((ClientTheme.color(r.y() / 10) & 0x00FFFFFF) | 0xAA000000) : 0xCC17171F;
                ctx.fill(r.x(), r.y(), x2, y2, bg);
                ctx.drawTextWithShadow(textRenderer, r.module().getName(),
                        r.x() + 5, r.y() + 3, on ? 0xFFFFFFFF : 0xFFB0B0B8);
            } else {
                ctx.fill(r.x(), r.y(), x2, y2, 0xCC101016);
                Setting s = r.setting();
                String label;
                if (s instanceof NumberSetting n) {
                    double t = (n.get() - n.getMin()) / (n.getMax() - n.getMin());
                    int fillW = (int) (r.w() * MathHelper.clamp(t, 0.0, 1.0));
                    ctx.fill(r.x(), r.y(), r.x() + fillW, y2, (ClientTheme.color(2) & 0x00FFFFFF) | 0x88000000);
                    label = n.getName() + ": " + n.display();
                } else if (s instanceof BooleanSetting b) {
                    if (b.get()) ctx.fill(r.x(), r.y(), x2, y2, (ClientTheme.color(2) & 0x00FFFFFF) | 0x88000000);
                    label = b.getName();
                } else if (s instanceof ModeSetting m) {
                    label = m.getName() + ": " + m.getMode();
                } else {
                    label = s.getName();
                }
                ctx.drawTextWithShadow(textRenderer, label, r.x() + 8, r.y() + 3, 0xFFE0E0E8);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Row r : buildRows()) {
            if (mx < r.x() || mx >= r.x() + r.w() || my < r.y() || my >= r.y() + r.h()) continue;
            if (r.module() == null) return true;

            if (r.setting() == null) {
                if (button == 0) r.module().toggle();
                else if (button == 1) r.module().toggleExpanded();
                return true;
            }

            Setting s = r.setting();
            if (s instanceof BooleanSetting b && button == 0) {
                b.toggle();
            } else if (s instanceof ModeSetting m && button == 0) {
                m.cycle();
            } else if (s instanceof NumberSetting n && button == 0) {
                dragging = n;
                dragX = r.x();
                dragW = r.w();
                applyDrag(mx);
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void applyDrag(double mx) {
        if (dragging == null) return;
        double t = MathHelper.clamp((mx - dragX) / dragW, 0.0, 1.0);
        dragging.set(dragging.getMin() + t * (dragging.getMax() - dragging.getMin()));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            applyDrag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }
}
